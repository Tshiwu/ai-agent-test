import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Bot, Brain, Cpu, Database, Globe, Layers, Network, Shield, Sparkles, Zap } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [activeSection, setActiveSection] = useState("hero");

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setActiveSection(id);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-body selection:bg-primary selection:text-primary-foreground overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="w-6 h-6 text-primary animate-pulse" />
            <span className="font-display font-bold text-xl tracking-wider">AI AGENT<span className="text-primary">.NEXUS</span></span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            {["Concept", "Architecture", "Frameworks", "Applications", "Future"].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase())}
                className="text-sm font-medium hover:text-primary transition-colors uppercase tracking-widest opacity-80 hover:opacity-100"
              >
                {item}
              </button>
            ))}
          </div>
          <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10 font-display tracking-wide">
            EXPLORE DATA
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="/images/hero-bg.png" 
            alt="Neural Network Background" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/60 to-background"></div>
        </div>
        
        <div className="container relative z-10 px-4 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-mono mb-6 animate-in fade-in slide-in-from-bottom-4 duration-1000">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            SYSTEM ONLINE: AGENTIC ERA INITIATED
          </div>
          
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-primary to-secondary animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-200">
            THE RISE OF<br />AUTONOMOUS INTELLIGENCE
          </h1>
          
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-400">
            From passive tools to active agents. Explore the paradigm shift that is redefining human-computer interaction and reshaping industries.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-600">
            <Button 
              size="lg" 
              onClick={() => scrollToSection('concept')}
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-display tracking-wide min-w-[160px] h-12 text-base shadow-[0_0_20px_rgba(0,243,255,0.3)] hover:shadow-[0_0_30px_rgba(0,243,255,0.5)] transition-all duration-300"
            >
              INITIATE DIVE
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => scrollToSection('applications')} 
              className="border-white/20 hover:bg-white/5 font-display tracking-wide min-w-[160px] h-12 text-base backdrop-blur-sm"
            >
              VIEW USE CASES
            </Button>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-50">
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex justify-center pt-2">
            <div className="w-1 h-2 bg-white/50 rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Concept Section */}
      <section id="concept" className="py-24 relative">
        <div className="container px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h2 className="font-display text-4xl font-bold text-white flex items-center gap-3">
                  <Sparkles className="text-secondary w-8 h-8" />
                  What is an AI Agent?
                </h2>
                <div className="h-1 w-20 bg-gradient-to-r from-secondary to-transparent"></div>
              </div>
              
              <p className="text-lg text-muted-foreground leading-relaxed">
                An AI Agent is not just a chatbot. It is an autonomous entity capable of <span className="text-primary font-medium">perceiving</span> its environment, <span className="text-primary font-medium">reasoning</span> about goals, and <span className="text-primary font-medium">taking action</span> to achieve them.
              </p>
              
              <div className="grid gap-4">
                {[
                  { title: "Autonomy", desc: "Operates independently without constant human oversight." },
                  { title: "Perception", desc: "Gathers information through sensors, APIs, and data streams." },
                  { title: "Action", desc: "Executes tasks in the digital or physical world to change states." },
                  { title: "Learning", desc: "Adapts and improves performance over time based on feedback." }
                ].map((feature, i) => (
                  <div key={i} className="flex items-start gap-4 p-4 rounded-lg border border-white/5 bg-white/5 hover:bg-white/10 transition-colors group">
                    <div className="mt-1 w-2 h-2 rounded-full bg-secondary group-hover:shadow-[0_0_10px_rgba(188,19,254,0.8)] transition-all"></div>
                    <div>
                      <h3 className="font-display font-bold text-white mb-1">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">{feature.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-xl blur-2xl opacity-50"></div>
              <Card className="relative bg-black/40 border-white/10 backdrop-blur-xl overflow-hidden">
                <CardHeader>
                  <CardTitle className="font-display text-xl text-center">Agent vs. Assistant vs. Chatbot</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-3 gap-4 text-center text-xs font-mono text-muted-foreground mb-2">
                      <div>CHATBOT</div>
                      <div>ASSISTANT</div>
                      <div className="text-primary font-bold">AI AGENT</div>
                    </div>
                    
                    {[
                      { label: "Role", v1: "Passive", v2: "Reactive", v3: "Proactive" },
                      { label: "Goal", v1: "Conversation", v2: "Task Help", v3: "Goal Achievement" },
                      { label: "Scope", v1: "Pre-defined", v2: "User-led", v3: "Autonomous" },
                      { label: "Memory", v1: "None/Short", v2: "Session", v3: "Long-term" },
                    ].map((row, i) => (
                      <div key={i} className="grid grid-cols-3 gap-4 items-center relative py-2 border-b border-white/5 last:border-0">
                        <div className="text-center text-sm text-muted-foreground">{row.v1}</div>
                        <div className="text-center text-sm text-muted-foreground">{row.v2}</div>
                        <div className="text-center text-sm font-bold text-white bg-primary/10 py-1 rounded border border-primary/20 shadow-[0_0_10px_rgba(0,243,255,0.1)]">{row.v3}</div>
                        <div className="absolute -left-2 top-1/2 -translate-y-1/2 text-[10px] font-mono text-white/30 -rotate-90 origin-center w-8">{row.label}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Architecture Section */}
      <section id="architecture" className="py-24 bg-black/30 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
        
        <div className="container px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="font-display text-4xl font-bold text-white mb-4">Core Architecture</h2>
            <p className="text-muted-foreground">The cognitive engine driving autonomous behavior, powered by the PPA (Perception-Planning-Action) model.</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 relative">
            {/* Connecting Lines (Desktop) */}
            <div className="hidden lg:block absolute top-1/2 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-primary/30 to-transparent -translate-y-1/2 z-0"></div>

            {[
              { 
                icon: <Globe className="w-10 h-10 text-primary" />, 
                title: "Perception", 
                desc: "The sensory interface. Agents ingest multimodal data (text, vision, audio) to understand the current state of the world.",
                details: ["Sensors & APIs", "Data Ingestion", "Context Awareness"]
              },
              { 
                icon: <Brain className="w-10 h-10 text-secondary" />, 
                title: "Brain (LLM)", 
                desc: "The central processing unit. Large Language Models provide the reasoning capabilities to analyze data and formulate plans.",
                details: ["Reasoning", "Decision Making", "Knowledge Retrieval"],
                highlight: true
              },
              { 
                icon: <Zap className="w-10 h-10 text-primary" />, 
                title: "Action", 
                desc: "The execution layer. Agents use tools and actuators to impact the environment and achieve their objectives.",
                details: ["Tool Use", "API Calls", "Physical Actuation"]
              }
            ].map((card, i) => (
              <Card key={i} className={`relative z-10 bg-card/80 backdrop-blur-md border-white/10 hover:border-primary/50 transition-all duration-500 group ${card.highlight ? 'scale-110 shadow-[0_0_50px_rgba(188,19,254,0.2)] border-secondary/50' : ''}`}>
                <CardHeader>
                  <div className="mb-4 p-3 rounded-full bg-white/5 w-fit group-hover:scale-110 transition-transform duration-300 border border-white/10">
                    {card.icon}
                  </div>
                  <CardTitle className="font-display text-2xl">{card.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-6">{card.desc}</p>
                  <ul className="space-y-2">
                    {card.details.map((detail, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm font-mono text-white/70">
                        <div className="w-1 h-1 bg-primary rounded-full"></div>
                        {detail}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-16 p-8 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="flex-1">
                <h3 className="font-display text-2xl font-bold text-white mb-4 flex items-center gap-2">
                  <Database className="text-primary" />
                  Memory Systems
                </h3>
                <p className="text-muted-foreground mb-4">
                  Just like humans, Agents rely on memory to maintain context and learn.
                </p>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded bg-black/40 border border-white/5">
                    <div className="font-bold text-primary mb-1">Short-term Memory</div>
                    <div className="text-xs text-muted-foreground">Context window, current session data</div>
                  </div>
                  <div className="p-4 rounded bg-black/40 border border-white/5">
                    <div className="font-bold text-secondary mb-1">Long-term Memory</div>
                    <div className="text-xs text-muted-foreground">Vector databases (RAG), historical knowledge</div>
                  </div>
                </div>
              </div>
              <div className="flex-1 relative h-64 w-full rounded-lg overflow-hidden border border-white/10">
                 <img src="/images/architecture-diagram.png" alt="Architecture Diagram" className="w-full h-full object-cover" />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-4">
                   <div className="font-mono text-xs text-primary">FIG 2.1: SYSTEM ARCHITECTURE VISUALIZATION</div>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Frameworks Section */}
      <section id="frameworks" className="py-24 relative">
        <div className="container px-4">
          <div className="mb-12">
            <h2 className="font-display text-4xl font-bold text-white mb-4">Development Frameworks</h2>
            <p className="text-muted-foreground max-w-2xl">The tools empowering developers to build the next generation of intelligent agents.</p>
          </div>

          <Tabs defaultValue="langchain" className="w-full">
            <TabsList className="w-full flex flex-wrap justify-start gap-2 bg-transparent p-0 mb-8 h-auto">
              {["LangChain", "Botpress", "CrewAI", "AutoGen", "Microsoft Semantic Kernel"].map((fw) => (
                <TabsTrigger 
                  key={fw} 
                  value={fw.toLowerCase().replace(/\s/g, '-')}
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground border border-white/10 bg-white/5 hover:bg-white/10 px-6 py-3 rounded-md transition-all font-display tracking-wide"
                >
                  {fw}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {[
              { 
                id: "langchain", 
                name: "LangChain", 
                type: "General Purpose", 
                desc: "The industry standard for building LLM applications. Modular, extensive ecosystem, and highly controllable.",
                bestFor: "Research & Custom Agents"
              },
              { 
                id: "botpress", 
                name: "Botpress", 
                type: "Enterprise Platform", 
                desc: "Visual builder for enterprise-grade agents. Low-code interface with powerful NLU and integration capabilities.",
                bestFor: "Enterprise Deployment"
              },
              { 
                id: "crewai", 
                name: "CrewAI", 
                type: "Multi-Agent Orchestration", 
                desc: "Framework for orchestrating role-playing autonomous agents. Great for delegating tasks among a 'crew' of agents.",
                bestFor: "Collaborative Tasks"
              },
              { 
                id: "autogen", 
                name: "AutoGen", 
                type: "Conversational Framework", 
                desc: "Enables next-gen LLM applications via multiple agents that can converse with each other to solve tasks.",
                bestFor: "Complex Workflows"
              },
              { 
                id: "microsoft-semantic-kernel", 
                name: "Microsoft Semantic Kernel", 
                type: "Enterprise SDK", 
                desc: "Integrates LLMs with existing code. Designed to be embedded into applications, especially in the .NET ecosystem.",
                bestFor: "App Integration"
              }
            ].map((fw) => (
              <TabsContent key={fw.id} value={fw.id} className="animate-in fade-in slide-in-from-right-4 duration-500">
                <Card className="bg-card/50 border-primary/20 backdrop-blur-md">
                  <CardContent className="p-8">
                    <div className="flex flex-col md:flex-row gap-8 items-start">
                      <div className="flex-1 space-y-6">
                        <div>
                          <div className="text-primary font-mono text-sm mb-2">{fw.type}</div>
                          <h3 className="font-display text-3xl font-bold text-white mb-4">{fw.name}</h3>
                          <p className="text-lg text-muted-foreground">{fw.desc}</p>
                        </div>
                        
                        <div className="p-4 bg-white/5 rounded border border-white/10">
                          <div className="text-sm text-muted-foreground mb-1">Best For:</div>
                          <div className="font-bold text-white flex items-center gap-2">
                            <ArrowRight className="w-4 h-4 text-secondary" />
                            {fw.bestFor}
                          </div>
                        </div>
                      </div>
                      
                      <div className="w-full md:w-1/3 aspect-video bg-black/50 rounded-lg border border-white/10 flex items-center justify-center relative overflow-hidden group">
                        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20"></div>
                        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-500">
                          <Layers className="text-white w-8 h-8" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* Applications Section */}
      <section id="applications" className="py-24 bg-black/30">
        <div className="container px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="font-display text-4xl font-bold text-white mb-4">Real-World Impact</h2>
            <p className="text-muted-foreground">From theory to practice. How AI Agents are revolutionizing industries today.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Smart Customer Service",
                stat: "40%",
                statLabel: "Efficiency Increase",
                desc: "7x24 autonomous handling of complex queries with emotional intelligence.",
                icon: <Bot />
              },
              {
                title: "Sales & Marketing",
                stat: "35%",
                statLabel: "Conversion Uplift",
                desc: "Automated lead scoring, personalized outreach, and dynamic content generation.",
                icon: <Zap />
              },
              {
                title: "Enterprise Ops",
                stat: "100%",
                statLabel: "Process Coverage",
                desc: "Full-chain automation from supply chain management to HR workflows.",
                icon: <Network />
              },
              {
                title: "Creative Content",
                stat: "90%",
                statLabel: "Faster Output",
                desc: "Autonomous market research, ideation, and multi-format content creation.",
                icon: <Sparkles />
              },
              {
                title: "Data Analysis",
                stat: "15%",
                statLabel: "Auto Decisions",
                desc: "Self-driving analytics that not only report data but act on insights.",
                icon: <Database />
              },
              {
                title: "Security & Risk",
                stat: "-80%",
                statLabel: "Response Time",
                desc: "Real-time threat detection and autonomous defensive maneuvers.",
                icon: <Shield />
              }
            ].map((app, i) => (
              <Card key={i} className="bg-white/5 border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300 group overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div className="p-2 bg-black/40 rounded-lg text-primary group-hover:text-secondary transition-colors">
                      {app.icon}
                    </div>
                    <div className="text-right">
                      <div className="font-display text-3xl font-bold text-white group-hover:text-primary transition-colors">{app.stat}</div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{app.statLabel}</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardTitle className="font-display text-lg mb-2">{app.title}</CardTitle>
                  <p className="text-sm text-muted-foreground">{app.desc}</p>
                </CardContent>
                <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-secondary transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Future Section */}
      <section id="future" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="/images/future-city.png" alt="Future City" className="w-full h-full object-cover opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/40"></div>
        </div>

        <div className="container relative z-10 px-4">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <div className="flex-1 space-y-8">
              <h2 className="font-display text-5xl font-bold text-white leading-tight">
                The Horizon: <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">2026 & Beyond</span>
              </h2>
              
              <div className="space-y-6">
                {[
                  { year: "2026", title: "Long-term Autonomy", desc: "Agents with weeks-long context windows and persistent memory." },
                  { year: "2027", title: "Multi-Agent Swarms", desc: "Collaborative ecosystems of specialized agents solving macro problems." },
                  { year: "2028", title: "NUI Revolution", desc: "Natural Language Interfaces replacing GUIs as the primary interaction mode." },
                  { year: "Future", title: "Human-Agent Symbiosis", desc: "Seamless integration of AI agents into every aspect of work and life." }
                ].map((trend, i) => (
                  <div key={i} className="flex gap-6 group">
                    <div className="flex flex-col items-center">
                      <div className="w-3 h-3 rounded-full bg-primary group-hover:bg-secondary transition-colors shadow-[0_0_10px_rgba(0,243,255,0.5)]"></div>
                      {i !== 3 && <div className="w-0.5 h-full bg-white/10 group-hover:bg-white/20 transition-colors my-2"></div>}
                    </div>
                    <div className="pb-8">
                      <div className="font-mono text-primary text-sm mb-1">{trend.year}</div>
                      <h3 className="font-display text-xl font-bold text-white mb-2">{trend.title}</h3>
                      <p className="text-muted-foreground">{trend.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex-1">
              <Card className="bg-black/60 border-primary/30 backdrop-blur-xl p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-20">
                  <Cpu className="w-32 h-32 text-primary" />
                </div>
                <h3 className="font-display text-2xl font-bold text-white mb-6">Ready to Deploy?</h3>
                <p className="text-lg text-muted-foreground mb-8">
                  The era of Agentic AI is here. Whether you are automating workflows, enhancing customer experience, or building the next big thing, the time to start is now.
                </p>
                <Button size="lg" className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-white font-display tracking-wide border-0">
                  START BUILDING AGENTS
                </Button>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/10 bg-black/50">
        <div className="container px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <Bot className="w-6 h-6 text-primary" />
            <span className="font-display font-bold text-xl tracking-wider text-white">AI AGENT<span className="text-primary">.NEXUS</span></span>
          </div>
          <p className="text-muted-foreground text-sm mb-8">
            Empowering the future of autonomous intelligence.
          </p>
          <div className="text-xs text-white/30 font-mono">
            © 2026 MANUS AI. ALL SYSTEMS NOMINAL.
          </div>
        </div>
      </footer>
    </div>
  );
}
